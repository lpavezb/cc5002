<!DOCTYPE html>
<html>
<head>
	<title>Taller 6</title>
</head>
<body>
<h1>Subir Archivos Taller 6</h1>
	<form action="subir.php" method="post" enctype="multipart/form-data">
		<input type="file" name="archivo">
		<br><br>
		<button>Subir Archivo</button>
	</form>
</body>
</html>
